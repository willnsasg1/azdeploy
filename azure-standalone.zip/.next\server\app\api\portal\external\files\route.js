var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/portal/external/files/route.js")
R.c("server/chunks/[root-of-the-server]__b6241853._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_portal_external_files_route_actions_b7669f72.js")
R.m(13543)
module.exports=R.m(13543).exports
