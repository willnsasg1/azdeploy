module.exports=[19532,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_%5BprojectId%5D_route_actions_37e3e399.js.map