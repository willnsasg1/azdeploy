module.exports=[28665,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invites_%5Btoken%5D_accept_route_actions_2fb2995b.js.map