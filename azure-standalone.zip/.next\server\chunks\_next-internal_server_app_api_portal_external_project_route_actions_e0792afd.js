module.exports=[22162,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_external_project_route_actions_e0792afd.js.map