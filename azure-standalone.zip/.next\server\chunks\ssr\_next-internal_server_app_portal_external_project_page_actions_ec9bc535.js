module.exports=[7338,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_external_project_page_actions_ec9bc535.js.map