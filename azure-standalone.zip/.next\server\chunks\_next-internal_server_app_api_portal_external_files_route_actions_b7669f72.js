module.exports=[72773,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_external_files_route_actions_b7669f72.js.map