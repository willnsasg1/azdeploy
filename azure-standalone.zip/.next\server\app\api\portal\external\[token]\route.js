var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/portal/external/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__0f077501._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_portal_external_[token]_route_actions_0942b208.js")
R.m(95917)
module.exports=R.m(95917).exports
