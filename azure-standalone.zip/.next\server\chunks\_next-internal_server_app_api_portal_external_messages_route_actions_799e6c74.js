module.exports=[70591,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_external_messages_route_actions_799e6c74.js.map