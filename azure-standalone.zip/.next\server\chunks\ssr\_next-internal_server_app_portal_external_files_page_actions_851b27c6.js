module.exports=[42104,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_external_files_page_actions_851b27c6.js.map