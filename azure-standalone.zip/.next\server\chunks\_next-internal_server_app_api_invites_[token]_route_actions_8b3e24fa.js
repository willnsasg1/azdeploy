module.exports=[52061,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invites_%5Btoken%5D_route_actions_8b3e24fa.js.map