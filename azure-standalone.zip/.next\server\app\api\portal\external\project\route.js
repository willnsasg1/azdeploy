var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/portal/external/project/route.js")
R.c("server/chunks/[root-of-the-server]__c5bfed74._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_portal_external_project_route_actions_e0792afd.js")
R.m(68822)
module.exports=R.m(68822).exports
