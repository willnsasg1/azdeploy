var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/route.js")
R.c("server/chunks/[root-of-the-server]__5036c43c._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_route_actions_38c611ee.js")
R.m(77981)
module.exports=R.m(77981).exports
