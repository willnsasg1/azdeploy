module.exports=[98015,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_external_activity_route_actions_31693d70.js.map