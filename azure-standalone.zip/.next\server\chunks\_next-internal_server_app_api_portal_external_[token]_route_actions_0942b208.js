module.exports=[31301,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_portal_external_%5Btoken%5D_route_actions_0942b208.js.map