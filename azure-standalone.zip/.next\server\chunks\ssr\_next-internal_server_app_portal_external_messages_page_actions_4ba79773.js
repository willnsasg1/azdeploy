module.exports=[80408,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_external_messages_page_actions_4ba79773.js.map