module.exports=[49578,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_projects_page_actions_42ca3f3e.js.map