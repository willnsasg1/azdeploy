module.exports=[73535,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_portal_external_page_actions_37c99412.js.map