var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invites/[token]/accept/route.js")
R.c("server/chunks/[root-of-the-server]__e00c6b1e._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_invites_[token]_accept_route_actions_2fb2995b.js")
R.m(98360)
module.exports=R.m(98360).exports
