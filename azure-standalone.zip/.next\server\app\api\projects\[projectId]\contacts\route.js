var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[projectId]/contacts/route.js")
R.c("server/chunks/[root-of-the-server]__12ea7d26._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/ce889_server_app_api_projects_[projectId]_contacts_route_actions_33988672.js")
R.m(13934)
module.exports=R.m(13934).exports
