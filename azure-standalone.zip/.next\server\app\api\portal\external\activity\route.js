var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/portal/external/activity/route.js")
R.c("server/chunks/[root-of-the-server]__31217e50._.js")
R.c("server/chunks/[root-of-the-server]__2d30ee64._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_portal_external_activity_route_actions_31693d70.js")
R.m(66596)
module.exports=R.m(66596).exports
