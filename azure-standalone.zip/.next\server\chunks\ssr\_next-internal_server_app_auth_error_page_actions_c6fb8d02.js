module.exports=[20622,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_error_page_actions_c6fb8d02.js.map