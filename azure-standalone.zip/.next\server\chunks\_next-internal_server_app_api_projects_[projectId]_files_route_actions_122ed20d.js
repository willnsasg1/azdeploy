module.exports=[57733,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_projects_%5BprojectId%5D_files_route_actions_122ed20d.js.map