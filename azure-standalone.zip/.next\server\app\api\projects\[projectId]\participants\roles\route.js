var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[projectId]/participants/roles/route.js")
R.c("server/chunks/[root-of-the-server]__465e961a._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/ce889_server_app_api_projects_[projectId]_participants_roles_route_actions_eee97f35.js")
R.m(61703)
module.exports=R.m(61703).exports
